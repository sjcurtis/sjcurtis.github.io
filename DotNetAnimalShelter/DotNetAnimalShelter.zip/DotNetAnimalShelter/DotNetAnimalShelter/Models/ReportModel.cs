﻿// View model used to pass multiple models to a single view.
namespace DotNetAnimalShelter.Models
{
	public class ReportModel
	{

		public List<Animal> Animals { get; set; }

		public IEnumerable<BreedCount> Breeds { get; set; }
	}

	// Stores the count for a corresponding breed.
	public class BreedCount
	{
		public string? Name { get; set;}
		public int Count { get; set;}
	}
}
